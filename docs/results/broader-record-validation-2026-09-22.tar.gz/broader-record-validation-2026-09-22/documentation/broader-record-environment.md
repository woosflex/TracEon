# Broader validation environment — 2026-09-22

Continues the user-authorized local CPU environment. No cloud or remote execution.
Python3.14.7 virtual environment: build/broader-validation-venv. Pinned official
pyfastx2.3.1 CPython3.14 manylinux2_28 wheel downloaded to
build/research-inputs/pyfastx-wheels, installed with --no-index --no-deps.
Sandbox download initially failed DNS; explicit network escalation succeeded.
Embedded C++ driver uses python3-config --includes/--embed --ldflags and existing
pinned HTSlib/TracEon static libraries. Only pyfastx arm initializes CPython.
PYTHONPATH selects the local wheel; no project runtime dependency is added.

Local systemd user transient service probe succeeded with actual memory.max
536870912 and memory.swap.max0. Cgroup filesystem is read-only in sandbox;
pressure orchestration and loopback jobs use approved execution escalation.
Limits apply to child service cgroups only; no host settings are modified.
Fresh input copies inside each service avoid external page-cache charge evasion.
CPUs8–11 shared among workers/server; controllerCPU16; not exclusively reserved.

Artifacts: build/broader-record-validation-2026-09-22. Sources are sealed after
smoke and before measurement; preparation source is separately preserved.
The user confirmed no second machine is available; local tests are not independent-host
replication. No credentials or external services are required for local testing.
