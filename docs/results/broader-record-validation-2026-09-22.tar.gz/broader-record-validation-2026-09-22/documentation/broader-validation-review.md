# Internal methodological review — 2026-09-22

A separate assistant researcher reviewed the native/embedded worker and harness
before execution sealing. Corrections: matched random/ordered selections, digest
corruption check against its own fixture, preserved failure rows, named cgroup
units and timeout diagnostics, actual swap usage, host snapshots, archived
protocol and all source/helper hashes. Review found no remaining measurement
blocker. It is internal review, not independent research replication.

The pyfastx missing-ID failure was detected by smoke, then reproduced in plain
Python before timing. Failed fixture remains available. All-present workloads
avoid scoring a false miss as fast access. pyfastx is unmodified.

Successful units can be garbage-collected before external `systemctl show`;
saved internal counters remain authoritative. If a controller is killed and
final counters are absent, classify an OOM only when external unit diagnostics
positively support it; otherwise report a generic unit failure.

The user confirmed no second machine is available. No cross-host verification
is claimed. No global cache eviction, swap change, cloud resource or production
code change is part of these experiments.

Post-run independent audit: all 288 unique main observations, 864 cohorts and
2,396,160 deliveries match planned counts, bytes and digests. TracEon median
wins 7/12 vs HTSlib, 6/12 vs plain pyfastx, and 12/12 vs gzip pyfastx. Primary
short-record gains and long-record losses hold in every paired session. The
256MiB study confirms 0/6 completion for HTSlib/TracEon with OOM kills and 6/6
for both pyfastx arms. Million-record primary PSS is439.52 vs40.51MiB for
TracEon vs plain pyfastx. Analysis was pinned to CPU17 (CPU18 unavailable),
outside benchmark CPUs8–11 and controllerCPU16.

Final automated export verifies all 72 pressure outcomes: both pyfastx arms
complete18/18; HTSlib and TracEon each complete12/18 (all256MiB trials fail).
All60 completed trials validate737,280 additional record instances. Source and
index seals still match after the full-input missing-ID probe. Both complete
FASTQ inputs reproduce post-miss false negatives; the long FASTA reader recovers.
Both revised manuscripts pass Pandoc citation processing; old PDFs are stale.
