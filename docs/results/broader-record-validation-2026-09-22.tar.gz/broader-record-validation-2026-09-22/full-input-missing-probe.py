import json
from pathlib import Path
import pyfastx
root=Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text());rows=[]
for name,d in m['datasets'].items():
    key=Path(d['jobs']['0-random'][0]['ids']).read_text().splitlines()[0]
    for form in ('plain','gzip'):
        cls=pyfastx.Fastq if d['fastq'] else pyfastx.Fasta
        obj=cls(d['gzip'] if form=='gzip' else d['reads'],index_file=d['fxi'][form],**({} if d['fastq'] else {'uppercase':False}))
        observed=[]
        for k in (key,'__TRACEON_MISSING_CONTROL__',key):
            try:
                r=obj[k];observed.append({'id':k,'length':len(r.seq),'present':True})
            except KeyError:observed.append({'id':k,'present':False})
        rows.append({'dataset':name,'form':form,'queries':observed})
print(json.dumps({'pyfastx':pyfastx.__version__,'results':rows},indent=2))
