# Post-run audit — 2026-09-22

A separate assistant reviewer recomputed recorded worker digest/count/presence
checks, active spans, 30 distinct server lifetimes, and 3/3 arm-order balance.
All passed. This is an internal computational review, not external replication.
600 arm observations, 2,520 persistent workers, 18,579,456 timing record instances;
three passes total 7,560 worker passes and 55,738,368 record instances.
Scalar loses all 15 cells. Long records: eight losses, two unresolved comparisons.
Host boundary counters: no new swap-out, allocation-stall-normal or OOM kills;
204 swap-in pages and 214 major faults system-wide, with preexisting swap usage.
Boundary counters do not exclude transient pressure or isolate other host activity.

Post-analysis export validates all recorded outputs again. The normal/optimized
Python regression rejects changed IDs, sequence, quality, order and multiplicity.
Both revised manuscripts pass Pandoc citation processing to local HTML without
warnings. Existing PDFs predate these revisions and are not current renders.
No production code was changed by this benchmark extension. Repository-wide
diff whitespace checks still flag preexisting CRLF header edits outside this task.

Archive includes raw timing/memory files, request lists, manifests, logs, smoke
checks, execution/preparation source snapshots and post-analysis exporter.
Large source datasets, cache/index artifacts and worker executable are omitted;
local full artifacts remain and their recorded hashes support regeneration.
