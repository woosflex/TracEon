# Exploratory indexed setup-amortization follow-up

Written after viewing the completed64-query control, before running this extension.
The historical O3 cache is faster per query but costs more to initialize than
HTSlib1.24. Test total setup+verified retrieval at1k/5k/10k/50k requests,
six balanced pairs each, on the same single-line50k×1000-base FASTA. Sample with
replacement from all IDs with fixed seeds; identical lists per paired arm.
Fresh cache parsing and fresh indexed-handle loading per arm; existing FAI reused.
FAI construction remains separately reported, not charged to each indexed arm.
This probes observed reuse thresholds on this host, not a universal break-even
or a confirmation of historical64,000×claims. Preserve every outcome and digest.
