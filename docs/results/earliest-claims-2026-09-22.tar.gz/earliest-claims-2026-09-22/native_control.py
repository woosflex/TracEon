"""Post-hoc control: remove the HTSlib adapter's extra std::string copy."""
import json,subprocess,sys,statistics as st
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'benchmarks'))
from earliest_claim_study import run,save,digest,check,CPU,verify
base=Path(__file__).resolve().parent;out=base/'native-control';out.mkdir();verify(base)
s=(root/'benchmarks/earliest_claim_worker.cpp').read_text()
s=s.replace('int main(int argc,char** argv) try {','static void raw_field(EVP_MD_CTX* h,const char* p,size_t count) {unsigned char n[8];for(int i=0;i<8;++i)n[i]=uint64_t(count)>>(i*8);update(h,n,8);update(h,p,count);}\nint main(int argc,char** argv) try {')
s=s.replace('        std::string seq;','        std::string seq; std::unique_ptr<char,decltype(&free)> native(nullptr,free); hts_pos_t native_n=0;')
a='hts_pos_t n=0;std::unique_ptr<char,decltype(&free)> p(faidx_fetch_seq64(index.get(),key.c_str(),0,HTS_POS_MAX,&n),free);\n            if(!p||n<0)throw std::runtime_error("indexed miss");seq.assign(p.get(),n);'
b='native.reset(faidx_fetch_seq64(index.get(),key.c_str(),0,HTS_POS_MAX,&native_n));\n            if(!native||native_n<0)throw std::runtime_error("indexed miss");'
if a not in s:raise ValueError('source shape changed')
s=s.replace(a,b).replace('        if(seq.empty())throw std::runtime_error("empty result or miss");\n        field(h.get(),key);field(h.get(),seq);bytes+=seq.size();','        field(h.get(),key);\n        if(arm=="indexed") {raw_field(h.get(),native.get(),native_n);bytes+=native_n;}\n        else {if(seq.empty())throw std::runtime_error("empty result or miss");field(h.get(),seq);bytes+=seq.size();}')
p=out/'worker.cpp';p.write_text(s)
c=next(c for c in json.loads((base/'compile-commands.json').read_text()) if c[-1]==str(base/'O3/verified'));c=[str(p) if x==str(root/'benchmarks/earliest_claim_worker.cpp') else x for x in c];c[-1]=str(out/'worker');save(out/'compile-command.json',c);run(c,out,'compile')
plan=json.loads((base/'indexed-followup/plan.json').read_text());rows=[]
paths=[p,out/'worker',Path(__file__),base/'seal.json',base/'single.fa',base/'single.fai',base/'indexed-followup/plan.json']
seal={str(p):digest(p) for p in paths};save(out/'seal.json',seal)
for count in (64,10000):
 for session in range(6):
  job=({'ids':str(base/f's{session}.ids'),'expected':json.loads((base/f's{session}-expected.json').read_text())} if count==64 else plan['jobs'][f'{count}-{session}'])
  for arm in (('cache','indexed') if session%2==0 else ('indexed','cache')):
   r=json.loads(run(['taskset','-c',CPU,str(out/'worker'),arm,str(base/'single.fa'),job['ids'],str(base/'single.fai')],out,f'n{count}-s{session}-{arm}'));check(r,job['expected']);rows.append(dict(r,n=count,session=session,arm=arm))
save(out/'runs.json',rows)
summary=[]
for count in (64,10000):
 g={arm:sorted([r for r in rows if r['n']==count and r['arm']==arm],key=lambda x:x['session']) for arm in ('cache','indexed')}
 summary.append({'requests':count,'cache_query_ms':st.median(r['query_ms'] for r in g['cache']),'native_hts_query_ms':st.median(r['query_ms'] for r in g['indexed']),'cache_total_ms':st.median(r['total_ms'] for r in g['cache']),'native_hts_total_ms':st.median(r['total_ms'] for r in g['indexed']),'cache_total_wins':sum(c['total_ms']<h['total_ms'] for c,h in zip(g['cache'],g['indexed']))})
save(out/'summary.json',summary)
for p,h in seal.items():
 if digest(Path(p))!=h:raise ValueError('changed artifact')
verify(base);print(json.dumps(summary,indent=2))
