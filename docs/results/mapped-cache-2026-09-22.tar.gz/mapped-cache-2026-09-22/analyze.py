import json,statistics,sys
from pathlib import Path
out=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()/'benchmarks'))
from summarize_paired import interval
rows=json.loads((out/'equal-warmup-results.json').read_text());pairs=[]
for d in sorted({r['dataset'] for r in rows}):
 for baseline,target in [('indexed','v1'),('indexed','current'),('current','v1')]:
  a={r['rep']:r for r in rows if r['dataset']==d and r['arm']==baseline};b={r['rep']:r for r in rows if r['dataset']==d and r['arm']==target}
  dif=[a[i]['consume_ms']-b[i]['consume_ms'] for i in range(6)]
  pairs.append(dict(dataset=d,baseline=baseline,target=target,mean_saving_ms=statistics.mean(dif),exploratory_mean_saving_95pct_bootstrap_ms=interval(dif),wins=sum(x>0 for x in dif),pairs=6))
(out/'paired-analysis.json').write_text(json.dumps(pairs,indent=2)+'\n')
print(json.dumps(pairs,indent=2))
