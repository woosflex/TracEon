#ifndef TRACEON_SMARTSTRATEGY_H
#define TRACEON_SMARTSTRATEGY_H

#include "MapDefs.h"

#include <string>
#include <string_view>
#include <vector>
#include <deque>
#include <memory>
#include <shared_mutex>
#include <variant>
#include <filesystem>
#include <atomic>
#include <functional>
#include <optional>

namespace TracEon {

struct MMapHandle;

enum class FileFormat : uint8_t {
    DNA_FASTA = 0x00, RNA_FASTA = 0x01, PROTEIN_FASTA = 0x02,
    DNA_FASTQ = 0x03, RNA_FASTQ = 0x04, PROTEIN_FASTQ = 0x05,
    UNKNOWN = 0xFF
};

struct SequenceView {
    // NOTE:
    // - The Map Key (std::string_view) is NON-OWNING: it points into either
    //   the text_arena_ buffer (parse and binary v4/v5 restore) or manual_store_
    //   (addEntry()). Both backing stores are stable for the map's lifetime
    //   (arena is immutable-after-load; deque push_back never invalidates).
    //   No std::string is constructed on any insert path.
    // - SequenceView.id, sequence, and quality are NON-OWNING views pointing
    //   into the same stable buffers. For entries added via addEntry(), they
    //   point into manual_store_.
    std::string_view id;       
    std::string_view sequence; 
    std::string_view quality;  
};

// GenomeIndex: string_view keys (zero-copy, arena-backed — no std::string
// allocation on the insert path) with transparent lookup (find by
// string_view / const char* / std::string, no allocation on the read path).
using GenomeIndex = StringViewHashMap<SequenceView>;

// Keep NGS as a distinct variant alternative while retaining full identifiers
// as keys. unordered_dense resolves hash collisions with equality, so distinct
// identifiers can coexist; unlike the former uint64_t-only map, correctness no
// longer depends on an implementation-specific hash being collision-free.
struct NGSStringHash : TransparentStringHash {};
using NGSIndex = ankerl::unordered_dense::map<
    std::string_view, SequenceView, NGSStringHash, std::equal_to<>>;

enum class IndexMode { GENOME, NGS };

class SmartStrategy {
public:
    explicit SmartStrategy(IndexMode mode = IndexMode::GENOME);
    ~SmartStrategy();

    /**
     * @brief Load file with automatic format detection.
     * Detects .gz extension and GZIP magic bytes.
     * @throws std::runtime_error on corrupt/truncated input — truncated GZIP
     *         streams, trailing garbage after the last GZIP member, truncated
     *         tail members in concatenated GZIP, and OOM-guard rejections.
     */
    void loadFile(const std::string& filepath);
    
    /**
     * @brief Explicitly load a GZIP-compressed file.
     * Throws if file is not valid GZIP.
     * @throws std::runtime_error if the file is not valid GZIP, or if the
     *         stream is truncated / has trailing data after the last member
     *         (data-integrity rejection — partial data is never served).
     *
     * Failure atomicity (explicit contract): the cache is NEVER left in a
     * partial state, but the two failure classes differ in what survives:
     *   - Pre-flight validation failures — file unreadable, or the first two
     *     bytes are not the GZIP magic (0x1f 0x8b) — throw BEFORE the reload
     *     teardown (clearInternal()) begins, so a previously loaded snapshot
     *     stays fully intact and usable (getView()/get() still return old
     *     data; the failed load is a no-op on the cache state).
     *   - Mid-stream failures — truncated/corrupt GZIP streams, trailing
     *     garbage after the last member, OOM-guard rejections — are only
     *     detectable during decompression, which streams into the arena
     *     AFTER the reload teardown has begun (per the ADR-001 lifecycle
     *     contract, a reload invalidates the previous snapshot's views).
     *     These throw with the cache left EMPTY (never partial); reload from
     *     a valid source. Pre-flight checks are free, so they may preserve
     *     the old snapshot; preserving it through mid-stream failure would
     *     require a full second decompression or a full snapshot backup,
     *     contradicting the streaming/low-memory design.
     */
    void loadGzipFile(const std::string& filepath);

    /**
     * @brief Restore a `.traceon` v4 or v5 cache into decoded memory.
     *
     * v5 is the canonical portable format: explicit little-endian payload
     * fields, full identifiers in both modes, exact detected-format metadata,
     * and LZ4 Frame + whole-payload CRC32C. v4 remains readable for migration;
     * v1/v2/v3 are rejected. The mapped compressed file is released after
     * full decompression and validation, before publication.
     * @throws std::runtime_error on malformed/implausible cache files: wrong
     *         magic or version, unsupported codec/mode, truncated payloads or
     *         frames, wrong logical length, checksum mismatch, record counts
     *         exceeding the payload bytes, or OOM-guard rejections. A failed
     *         load never publishes partial state (failure atomicity).
     */
    void loadBinary(const std::string& filepath);
    /**
     * @brief Write the current cache as a canonical v5 binary cache file.
     *
     * v5 = "TRO\x05" header (codec flags, index mode, detected format,
     * logical length, frame length, CRC32C) + a portable little-endian payload
     * in a streamed LZ4 Frame. The checksum is computed incrementally.
     * @throws std::runtime_error if the file cannot be written or LZ4 Frame
     *         compression fails.
     */
    void saveBinary(const std::string& filepath) const;

    // --- Manual Entry Support ---
    /**
     * @brief Add a record during the build phase.
     * @throws std::logic_error if called after a load (immutable-after-load
     *         contract, ADR-001): once data_loaded_ is set the index is frozen.
     *         Legal only before any loadFile()/loadBinary() or after
     *         clearCache().
     */
    void addEntry(const std::string& id, const std::string& seq, const std::string& qual);

    /**
     * @brief Borrowed view of a sequence payload.
     *
     * Header descriptions, FASTQ plus-line metadata, and quality scores are
     * not returned here. Use getQuality()/the Cache FASTQ record API for an
     * owned quality payload.
     *
     * @return A std::string_view pointing into immutable text_arena_ or
     *         manual_store_ storage. Empty means either not found or a valid
     *         zero-length FASTQ sequence; use hasSequence() to distinguish.
     *
     * @warning LIFECYCLE CONTRACT (reader quiescence — see ADR-001 and the
     *          README "Lifecycle contract" section): the returned view is
     *          NON-OWNING and is valid only while the same loaded snapshot
     *          stays installed. It becomes DANGLING the moment clearCache(),
     *          a reload (loadFile/loadGzipFile/loadBinary), or destruction
     *          begins. Reads are safe concurrently with other reads, but the
     *          application MUST stop using all views from a snapshot before
     *          clearing/reloading/destroying the cache. The write-side mutex
     *          serializes writers only; it does NOT reclaim memory from
     *          readers and is deliberately NOT taken on this read path.
     *
     * @note TRACEON_DEBUG_LIFECYCLE (opt-in) adds a reader counter that warns
     *       in clearInternal() if a getView() lookup overlaps a teardown — a
     *       diagnostic for coordinated misuse, not a synchronization mechanism.
     */
    std::string_view getView(const std::string_view& sequence_id) const;
    std::string getSequence(const std::string& sequence_id) const;
    std::string getQuality(const std::string& sequence_id) const;
    bool hasSequence(const std::string& sequence_id) const;
    
    size_t getFileCacheSize() const;
    std::vector<std::string> getAllKeys() const;
    void clearCache();

    /**
     * @brief Bytes held by the installed snapshot's arena-style stores
     * (text arena + manual addEntry() bytes). Informational; reported by the
     * remote STATS message as "arena bytes" (v2.3.0 remote access).
     */
    size_t getArenaBytes() const;
    
    
    FileFormat getDetectedFormat() const { return detected_format_; }
    IndexMode getIndexMode() const; 

private:
    std::vector<char> text_arena_;
    std::unique_ptr<MMapHandle> mmap_handle_;
    std::variant<GenomeIndex, NGSIndex> file_cache_;
    
    // Stable string storage for entries added via addEntry().
    // std::deque provides reference stability: push_back never invalidates
    // references/pointers to existing elements, so string_views into it are safe.
    std::deque<std::string> manual_store_;

    // Running total of bytes held in manual_store_. Checked against
    // getAvailableMemory() in addEntry() so manual entries — the only
    // remaining unbounded growth path in this class — fail loudly instead
    // of growing without limit.
    std::atomic<size_t> manual_store_bytes_{0};

    // Running total of the serialized (uncompressed) binary-cache payload
    // size, updated incrementally at every record insertion point instead
    // of being recomputed by walking the whole map at saveBinary() time.
    // Starts at sizeof(uint64_t): serializePayload() always writes an 8-byte
    // record-count header up front, even with zero records, so this base
    // must be present from construction (not just after a parse/restore
    // that calls refreshPayloadEstimate()) for addEntry()-only usage to
    // produce a correct estimate.
    mutable std::atomic<size_t> serialized_size_estimate_{sizeof(uint64_t)};

    FileFormat detected_format_;
    IndexMode index_mode_;
    // Write-side serialization ONLY (ADR-001): never taken on the getView()
    // read path. Declared BEFORE the cache-line-padded hot-atomic block so
    // rwlock state churn (getFileCacheSize()/getAllKeys()/writers) can never
    // land on a line a reader is loading — alignas(64) on data_ready_ below
    // forces the compiler to pad past this member before the hot block.
    mutable std::shared_mutex cache_mutex_;

    // ── Hot read-path atomics: cache-line separation (v2.3.0 audit) ─────────
    // Each of the read-path atomics below is alignas(64)-pinned to its own
    // cache line. Honest audit summary of the v2.3.0 read path:
    //   * DEFAULT (non-debug) builds: once the snapshot is installed, the
    //     getView() fast path is a pure acquire LOAD of data_ready_ — no RMW
    //     of any of these on the read path. Pure loads on a shared line cost
    //     no coherence traffic, so there is NO measurable false sharing
    //     among concurrent immutable-phase readers. The separation is
    //     PREVENTIVE here, not a steady-state throughput fix.
    //   * The separation IS a real fix for the two paths that DO write these
    //     lines while readers may be loading them: (a) the load→read
    //     transition and clearCache()/reload teardown, which flip
    //     data_ready_/data_loaded_ (store/release) and take cache_mutex_
    //     while other threads hold no lock; and (b) TRACEON_DEBUG_LIFECYCLE
    //     builds, where EVERY getView() RMWs active_readers_
    //     (fetch_add/fetch_sub). Pre-fix, data_ready_, active_readers_ and
    //     data_loaded_ sat within ~10 bytes of each other (same cache line),
    //     so a debug-build lookup bounced that line across all reader cores
    //     and serialized every thread's data_ready_ load behind the RMW.
    //     Pinning each atomic to its own line contains that traffic.
    //   * alignas(64) on data_ready_ also guarantees the block shares no
    //     line with cache_mutex_ / the enums above.

    /**
     * Lock-Free Read Signal
     * True only when all data is loaded and immutable.
     */
    alignas(64) std::atomic<bool> data_ready_{false};

#ifdef TRACEON_DEBUG_LIFECYCLE
    /**
     * Reader-quiescence diagnostic (opt-in via -DTRACEON_DEBUG_LIFECYCLE).
     *
     * Incremented for the duration of each getView() call; clearInternal()
     * warns (std::cerr) if any readers are still inside getView() when the
     * snapshot is torn down. LIMITATION: catches a reader whose LOOKUP
     * overlaps a clear; it CANNOT detect a caller that retained the returned
     * std::string_view and dereferences it after clearCache()/reload/
     * destruction completes. Diagnostic only — NOT synchronization (see
     * ADR-001 reader-quiescence section).
     *
     * alignas(64): every getView() RMWs this counter; keeping it off the
     * data_ready_/data_loaded_ lines stops debug-build lookups from bouncing
     * the read signal across cores (see audit note above).
     */
    alignas(64) mutable std::atomic<size_t> active_readers_{0};
#endif

    /**
     * Immutable-after-load signal (Bug 3 fix, ADR-001).
     *
     * Distinct from data_ready_: data_ready_ is also set by addEntry() so
     * lock-free reads can see manually-added entries during a build phase,
     * which would make it useless as an "is the cache frozen?" test. This
     * flag is set true ONLY by the load paths (loadFile/loadGzipFile via
     * parseArena(), and loadBinary()) and reset by clearInternal()
     * (clearCache()). Once true, the index is truly immutable: addEntry()
     * throws std::logic_error instead of mutating the map under concurrent
     * lock-free readers.
     */
    alignas(64) std::atomic<bool> data_loaded_{false};

    void determine_format_from_cache(std::optional<bool> structural_fastq = std::nullopt);
    bool isNucleotideSequence(std::string_view data) const;
    bool hasRNA(std::string_view data) const;
    void clearInternal();
    void validateInputArena(bool is_fastq) const;

    /**
     * @brief Set by load paths (loadFile/loadGzipFile/loadBinary) so
     * addEntry() can enforce the immutable-after-load contract.
     */
    void markDataLoaded();

    /**
     * @brief Serialize payload (count + all records), pushing bytes through
     * `sink` as they're produced rather than materializing a full in-memory
     * copy. Used by saveBinary() (v3 streaming format) so peak memory during
     * save stays bounded regardless of dataset size.
     */
    void serializePayload(const std::function<void(const char*, size_t)>& sink) const;

    /**
     * @brief Serialized (uncompressed) payload size, used to size the v5
     * header before streaming starts. Backed by serialized_size_estimate_,
     * which is updated incrementally at every record insertion rather than
     * recomputed by walking the whole map here.
     */
    size_t estimatePayloadSize() const;

    /**
     * @brief Recompute serialized_size_estimate_ by walking file_cache_.
     * Called once after a full (re)parse or binary-cache restore where the
     * exact size isn't already known for free; addEntry() maintains the
     * estimate incrementally after this point without needing another walk.
     */
    void refreshPayloadEstimate();

    /**
     * @brief Scan a compressed GZIP file for stream boundaries.
     * Returns byte offsets of each GZIP stream header found.
     * Size == 1 means single-stream; size > 1 means concatenated streams.
     */
    std::vector<size_t> scanGzipStreams(const std::string& filepath) const;

    /**
     * @brief Decompress concatenated GZIP streams in parallel into text_arena_.
     * Each stream is decompressed by a separate thread using zlib-ng inflate().
     * @param filepath Path to the compressed file
     * @param stream_offsets Stream start byte offsets from scanGzipStreams()
     */
    void loadGzipParallel(const std::string& filepath,
                          const std::vector<size_t>& stream_offsets);

    /**
     * @brief Single-threaded GZIP decompression into text_arena_ (original path).
     */
    void loadGzipSingleStream(const std::string& filepath);

    /**
     * @brief Cross-platform available physical memory in bytes.
     * Uses /proc/meminfo (Linux), sysctl (macOS), GlobalMemoryStatusEx (Windows).
     * Returns 0 on failure (caller falls back to geometric growth).
     */
    static size_t getAvailableMemory();
    
    /**
     * @brief Normalize multi-line FASTA sequences in-place within text_arena_.
     * Removes embedded newlines from sequence regions so parsers always see
     * single-line sequences. Header lines are preserved verbatim.
     * Only call for FASTA (first char '>'). No-op for empty arenas.
     */
    void normalizeFastaArena();

    /**
     * @brief Internal GZIP loader (used by both public methods)
     * Reads compressed stream into text_arena_ without parsing.
     */
    void loadGzipInternal(const std::string& filepath);
    
    // Helper to centralize parsing logic
    void parseArena();

    template <typename MapType> void parseFastaInternal(std::string_view content, MapType& map);
    template <typename MapType> void parseFastqInternal(std::string_view content, MapType& map);
    template <typename MapType> void parseFastaMultithreadedTemplate(std::string_view content, MapType& dest_map);
    template <typename MapType> void parseFastqMultithreadedTemplate(std::string_view content, MapType& dest_map);

};

} // namespace TracEon

#endif // TRACEON_SMARTSTRATEGY_H
