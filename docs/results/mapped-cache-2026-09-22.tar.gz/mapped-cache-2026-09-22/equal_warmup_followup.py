import json,random,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent
source=(out/'mapped_cache_worker.cpp').read_text().replace('if(mode=="query" && arm=="cache") {','if(false) {')
old='begin=Clock::now();size_t queries=mode=="hold"?count:10000;'
assert old in source
source=source.replace(old,'size_t queries=mode=="hold"?count:10000;\n    if(mode=="query")for(size_t i=0;i<queries;++i)get(ids[i]);\n    begin=Clock::now();')
worker=out/'equal-warmup-worker.cpp';worker.write_text(source)
commands=[json.loads(line)['command'] for line in (out/'commands.jsonl').read_text().splitlines() if json.loads(line)['command'][0]=='c++']
for cmd in commands:
 cmd=[str(worker) if x.endswith('/benchmarks/mapped_cache_worker.cpp') else x for x in cmd]
 cmd[-1]=cmd[-1].replace('-worker','-equal-worker')
 p=subprocess.run(cmd,capture_output=True,text=True)
 with (out/'equal-warmup-commands.jsonl').open('a') as f:f.write(json.dumps(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))+'\n')
 p.check_returncode()
rows=[]
for d in json.loads((out/'datasets.json').read_text()):
 folder=out/d['name']
 for rep in range(6):
  arms=['v1','current','indexed'];random.Random(500+rep).shuffle(arms)
  for arm in arms:
   cmd=list(map(str,['taskset','-c','8',out/('v1-equal-worker' if arm=='v1' else 'current-equal-worker'),'query','indexed' if arm=='indexed' else 'cache',folder/('reads.fa' if arm=='indexed' else arm+'.cache'),folder/'queries.txt',d['count'],d['length']]))
   p=subprocess.run(cmd,capture_output=True,text=True);p.check_returncode();r=json.loads(p.stdout)
   assert r['sha256']==d['query_sha256'] and r['records']==10000
   rows.append(dict(dataset=d['name'],rep=rep,arm=arm,command=cmd,stderr=p.stderr,**r))
 (out/'equal-warmup-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Validated',len(rows),'equal-warmup arms')
