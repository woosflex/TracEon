import json,re,statistics,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent;old=out/'v1'
cmd=['c++','-std=c++20','-O3','-DNDEBUG','-include','cstdint','-pthread','-I'+str(old),'-I'+str(old/'include'),str(out/'historical-traceon_driver.cpp')]+[str(old/'src'/s) for s in ['Cache.cpp','SmartStrategy.cpp','IEncodingStrategy.cpp']]+['-lz','-o',str(out/'original-driver')]
p=subprocess.run(cmd,text=True,capture_output=True)
(out/'original-driver-build.json').write_text(json.dumps(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2));p.check_returncode()
rows=[]
for d in json.loads((out/'datasets.json').read_text()):
 for rep in range(6):
  cmd=['taskset','-c','8',str(out/'original-driver'),'lookup',str(out/d['name']/'v1.cache'),'1000000','read',str(d['count'])]
  p=subprocess.run(cmd,text=True,capture_output=True);p.check_returncode()
  assert 'Key misses: 0/1000000' in p.stdout
  assert int(re.search(r'Sink=(\d+)',p.stdout)[1])==1000000*d['length']
  rows.append(dict(dataset=d['name'],rep=rep,command=cmd,stdout=p.stdout,stderr=p.stderr,mops=float(re.search(r'Throughput: ([\d.]+)',p.stdout)[1])/1e6))
(out/'original-driver-results.json').write_text(json.dumps(rows,indent=2)+'\n')
for d in sorted({r['dataset'] for r in rows}):print(d,statistics.median(r['mops'] for r in rows if r['dataset']==d))
