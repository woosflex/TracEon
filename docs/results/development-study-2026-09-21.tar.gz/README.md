# Preliminary development-tree evidence, 2026-09-21

This bundle includes raw timing/resource samples, setup and hardware manifests,
result summaries, deterministic ID lists, and the harness sources matching the
SHA-256 values recorded before each run. All server exits were verified as 0.
Full read/SAM outputs remain in the build directories and can be regenerated
from the linked public data. These are development-tree observations, not
final-release results or evidence of general end-to-end mapping superiority.
